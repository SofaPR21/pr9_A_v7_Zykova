class Bulldog : Dog {

    constructor(
    name: String = "Босс",  //Кличка
    height: Double = 35.0,  //рост по холке
    age: Double = 7.0, //фозраст песика
    color: String = "белый",  //окрас шерсти
    weight: Double = 10.5,  //вес
    temperament: String = "спокойный", //характер

) : super(name, "Бульдог", height, age, color, weight, temperament)



}
