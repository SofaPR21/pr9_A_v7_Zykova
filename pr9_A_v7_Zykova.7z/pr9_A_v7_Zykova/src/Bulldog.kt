class Bulldog (
    name: String,  //Кличка
    height: Double,  //рост по холке
    color: String,  //окрас шерсти
    weight: Double,  //вес
    temperament: String = "Спокойный" //характер

    ) : Dog(name, "Бульдог", height, color, weight, temperament){

    }
